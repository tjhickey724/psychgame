package pa07;

public enum Species {firefly, wasp, avatar};


