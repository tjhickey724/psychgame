package pa07;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.JPanel;
import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 * a GameView is a 2D view of a GameModel
 * the aspect of the view and model may be different
 * Since the GameModel is a square space, the GameView takes
 * the minimum of the width and height of the JPanel and uses
 * that to scale the GameModel to the Viewing window.
 * @author tim
 *
 */
public class GameView extends JPanel {

	private GameModel gm = null;
	
	public GameView(GameModel gm) {
		super();
		this.gm = gm;
		MouseInputListener ml =
				new CanvasMouseInputListener();
		this.addMouseListener(ml);
		this.addMouseMotionListener(ml);
	}
	
	public int toViewCoords(double x){
		int width = this.getWidth();
		int height = this.getHeight();
		int viewSize = (width<height)?width:height;
		return (int) Math.round(x/gm.size*viewSize);
	}
	
	public double toModelCoords(int x){
		int width = this.getWidth();
		int height = this.getHeight();
		int viewSize = (width<height)?width:height;
		return x*gm.size/viewSize;
	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		if (gm==null) return;
		int width = this.getWidth();
		int height = this.getHeight();
		g.setColor(Color.BLUE);
		g.fillRect(0,0,width,height);
		drawActor(g,gm.avatar,Color.GREEN);
		for(GameActor a:gm.actors){
			drawActor(g,a,Color.RED);
		}

	}
	
	private void drawActor(Graphics g, GameActor a,Color c){
		if (!a.active) return;
		int theRadius = toViewCoords(a.radius);
		int x = toViewCoords(a.x);
		int y = toViewCoords(a.y);
		
		switch (a.species){
		case firefly: c=Color.GREEN; break;
		case wasp: c=Color.RED; break;
		case avatar: c=Color.BLACK; break;
		}
		g.setColor(c);
		if (a.species==Species.avatar){
			g.drawOval(x-theRadius, y-theRadius, 2*theRadius, 2*theRadius);
		} else
			g.fillOval(x-theRadius, y-theRadius, 2*theRadius, 2*theRadius);

	}
	
	private class CanvasMouseInputListener extends MouseInputAdapter{
		public void mouseClicked(MouseEvent e){
			gm.paused=false;
		}
		public void mouseMoved(MouseEvent e){
			Point p = e.getPoint();
			double x = toModelCoords(p.x); 
			double y = toModelCoords(p.y);
			gm.avatar.x =x;
			gm.avatar.y =y;
			//System.out.println("x="+p.x+" y="+p.y);
			e.getComponent().repaint();		
		}
	}

}
